%chamar toda a logica de concatenar

%iniciar a lógica de reeverter